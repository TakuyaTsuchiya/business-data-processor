"""
フェイスSMS処理プロセッサー
準備中 - 将来実装予定
"""

def process_faith_sms_data(file_content: bytes):
    """フェイスSMS処理（準備中）"""
    raise NotImplementedError("フェイスSMS機能は準備中です")

def get_sample_template():
    """サンプルテンプレート（準備中）"""
    return None